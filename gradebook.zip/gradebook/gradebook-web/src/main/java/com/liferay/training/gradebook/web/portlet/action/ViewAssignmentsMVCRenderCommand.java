package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;
import com.liferay.training.gradebook.web.display.context.AssignmentsManagementToolbarDisplayContext;
import com.liferay.training.gradebook.web.internal.security.permission.resource.AssignmentPermission;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * This class represent render command for showing the assignment list
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=/",
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENTS
	},
	service = MVCRenderCommand.class
)
public class ViewAssignmentsMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Add Assignment List Related Attributes.
		addAssignmentListAttributes(renderRequest);
		
		// Add Clay Management Toolbar Related Attributes
		addManagementToolbarAttributes(renderRequest, renderResponse);
		
		// Add Permission Information To The Request
		renderRequest.setAttribute("assignmentPermission", _assignmentPermission);
		
		// Return To The View
		return "/view.jsp";
	}
	
	/**
	 * This method will add Clay Management Toolbar to the request with all the related setting and values
	 */
	private void addManagementToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		// Need to have LiferayPortletRequest and LiferayPortletResponse and HttpServlet Information
		LiferayPortletRequest liferayPortletRequest = _portal.getLiferayPortletRequest(renderRequest);
		LiferayPortletResponse liferayPortletResponse = _portal.getLiferayPortletResponse(renderResponse);
		HttpServletRequest httpServletRequest = _portal.getHttpServletRequest(renderRequest);
		
		// This needs to be passed to the Clay Management Toolbar
		AssignmentsManagementToolbarDisplayContext assignmentsManagementToolbarDisplayContext = new AssignmentsManagementToolbarDisplayContext(liferayPortletRequest, liferayPortletResponse, httpServletRequest);
		
		// Setting Up The Request With The Updated Clay Management Toolbar
		renderRequest.setAttribute("assignmentsManagementToolbarDisplayContext", assignmentsManagementToolbarDisplayContext);
	}
	
	/**
	 * This method will add the assignment list related attributes to the request
	 */
	private void addAssignmentListAttributes(RenderRequest renderRequest) {
		// Resolve What is a start and end for the search
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		int currentPage = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_CUR);
		int delta = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_DELTA_PARAM, SearchContainer.DEFAULT_DELTA);
		
		int start = ((currentPage > 0) ? (currentPage - 1) : 0) * delta;
		int end = start + delta;
		
		// Get Sorting Options
		// Notice that this doesn't really sort on title because the field is stored in XML format.
		// In real world this search would be integrated to the search engine to get the localized sort options.
		String orderByCol = ParamUtil.getString(renderRequest, "orderByCol", "title");
		String orderByType = ParamUtil.getString(renderRequest, "orderByType", "asc");
		
		// Create a Comparator Instance
		OrderByComparator<Assignment> orderByComparator = OrderByComparatorFactoryUtil.create("Assignment", orderByCol, !("asc").equals(orderByType));
		
		// Get Keywords. Currently I have not fully implemented it
		String keywords = ParamUtil.getString(renderRequest, "keywords");
		
		// Call For The Assignment Service to get the List of Assignment
		List<Assignment> assignments = _assignmentService.getAssignmentsByKeywords(themeDisplay.getScopeGroupId(), keywords, start, end, orderByComparator);
		
		// Setting Up The Request Object
		renderRequest.setAttribute("assignments", assignments);
		renderRequest.setAttribute("assignmentCount", _assignmentService.getAssignmentsCountByKeywords(themeDisplay.getScopeGroupId(), keywords));
	}
	
	@Reference
	private AssignmentPermission _assignmentPermission; 
	
	@Reference
	protected Portal _portal;
	
	@Reference
	protected AssignmentService _assignmentService;
}
