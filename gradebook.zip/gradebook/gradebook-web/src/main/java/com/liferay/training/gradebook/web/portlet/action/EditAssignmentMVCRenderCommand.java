package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.exception.NoSuchAssignmentException;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * This class represent the rendering view for adding or editing an assignment.
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class EditAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Create an empty instance of assignemnt
		Assignment assignment = null;
		
		// Need to get the information with respect to assignmentId
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId", 0);
		
		// Condition to check whether assignmentId obtained or null and do further process
		if(assignmentId > 0) {
			// Purpose is for editing
			try {
				// Call For Assignment Service To Get The Assignment Details Fetched.
				assignment = _assignmentService.getAssignment(assignmentId);
			}
			catch (NoSuchAssignmentException nsae) {
				nsae.printStackTrace();
			}
			catch (PortalException pe) {
				pe.printStackTrace();
			}
		}
		
		// Setting up back button here aswell
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
		String redirect = renderRequest.getParameter("redirect");
		System.out.println("Redirection Value : " + redirect);
		
		portletDisplay.setShowBackIcon(true);
		portletDisplay.setURLBack(redirect);
		
		// Setting up the request with assignment related information
		renderRequest.setAttribute("assignment", assignment);
		renderRequest.setAttribute("assignmentClass", Assignment.class);
		
		// Redirection to appropriate view
		return "/assignment/edit_assignment.jsp";
	}
	
	
	@Reference
	private AssignmentService _assignmentService; 
}
 