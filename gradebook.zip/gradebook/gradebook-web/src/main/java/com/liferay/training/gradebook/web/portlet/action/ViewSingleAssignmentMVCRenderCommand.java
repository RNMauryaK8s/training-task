package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import java.text.DateFormat;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * This is class represent rendering of the individual assignment information.
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class ViewSingleAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		// Need to retrive the assignmentId for getting the details about it.
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId", 0);
		try {
			// Call for the assignment service to get you assignment details.
			Assignment assignment = _assignmentService.getAssignment(assignmentId);
			DateFormat dateFormat = DateFormatFactoryUtil.getSimpleDateFormat("EEEEE, MMMMM dd, yyyy", renderRequest.getLocale());
			
			// Setup the attributes for the request so that it can be rendered to the appropriate view.
			renderRequest.setAttribute("assignment", assignment);
			renderRequest.setAttribute("dueDate", dateFormat.format(assignment.getDueDate()));
			renderRequest.setAttribute("createDate", dateFormat.format(assignment.getCreateDate()));
			
			// Setup up a back button to go back to all assignment view page
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
			
			String redirect = renderRequest.getParameter("redirect");
			System.out.println("Redirection Value : " + redirect);
			
			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			// Redirection to the appropriate view
			return "/assignment/view_assignment.jsp";
		}
		catch (PortalException pe) {
			throw new PortletException(pe);
		}
	}
	
	@Reference
	private AssignmentService _assignmentService;
}
