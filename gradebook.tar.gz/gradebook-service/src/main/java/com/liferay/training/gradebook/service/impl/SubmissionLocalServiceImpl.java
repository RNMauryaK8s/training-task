/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.model.Submission;
import com.liferay.training.gradebook.service.base.SubmissionLocalServiceBaseImpl;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the submission local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.liferay.training.gradebook.service.SubmissionLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author hgrahul
 * @see SubmissionLocalServiceBaseImpl
 */
@Component(
	property = "model.class.name=com.liferay.training.gradebook.model.Submission",
	service = AopService.class
)
public class SubmissionLocalServiceImpl extends SubmissionLocalServiceBaseImpl {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Use <code>com.liferay.training.gradebook.service.SubmissionLocalService</code> via injection or a <code>org.osgi.util.tracker.ServiceTracker</code> or use <code>com.liferay.training.gradebook.service.SubmissionLocalServiceUtil</code>.
	 */
	public Submission addSubmission(long assignmentId, long studentId, String submissionText, ServiceContext serviceContext) throws PortalException {
		// Get Information With Respect To Assignment
		Assignment assignment = assignmentPersistence.findByPrimaryKey(assignmentId);
		
		// Verify The User Exist - else throw exeception
		long userId = serviceContext.getUserId();
		User user = userLocalService.getUser(userId);
		
		// Verify The Student Exist - elese throw exeception
		User studentUser = userLocalService.getUser(studentId);
		
		// Validation For Sumissions Content
		
		// Create Submission Id
		long submissionId = counterLocalService.increment(Submission.class.getName());
		
		// Create A New Submission
		Submission submission = createSubmission(submissionId);
		
		// Populate The Field Values To The Submission Object
		submission.setSubmissionId(submissionId);
		submission.setAssignmentId(assignmentId);
		submission.setCompanyId(assignment.getCompanyId());
		submission.setGroupId(assignment.getGroupId());
		submission.setCreateDate(new Date());
		submission.setModifiedDate(new Date());
		
		submission.setUserId(userId);
		submission.setGrade(-1);
		submission.setStudentId(studentId);
		submission.setSubmissionText(submissionText);
		submission.setSubmitDate(new Date());
		
		// Return The Object
		return super.addSubmission(submission);
	}
	
	public Submission updateSubmission(long submissionId, String submissionText, ServiceContext serviceContext) throws PortalException {
		// Get Current Submission Information From SubmissionId
		Submission submission = getSubmission(submissionId);
		
		// Get Assignment Information Using Submission Object Throw an exception no assignment id return
		Assignment assignment = assignmentPersistence.findByPrimaryKey(submission.getAssignmentId());

		// Validation For Sumissions Content
		
		// Update New Content In Submission
		submission.setSubmissionText(submissionText);
		submission.setModifiedDate(new Date());

		// Persist and Return
		return super.updateSubmission(submission);
	}
	
	public List<Submission> getSubmissionsByAssignment(long groupId, long assignmentId) {
		return submissionPersistence.findByG_A(groupId, assignmentId);
	}
	
	public List<Submission> getSubmissionsByAssignment(long groupId, long assignmentId, int start, int end) {
		return submissionPersistence.findByG_A(groupId, assignmentId, start, end);
	}
	
	public int getSubmissionsCountByAssignment(long groupId, long assignmentId) {
		return submissionPersistence.countByG_A(groupId, assignmentId);
	}
	
	public Submission gradeSubmission(long submissionId, int grade) throws PortalException{
		// Get Submission Information Or Object
		Submission submission = getSubmission(submissionId);
		
		// Update The Grading Details
		submission.setGrade(grade);
		submission.setModifiedDate(new Date());
		
		return super.updateSubmission(submission);
	}
	
	public Submission gradeAndCommentSubmission(long submissionId, int grade, String comment) throws PortalException{
		// Get Submission Information Or Object
		Submission submission = getSubmission(submissionId);
		
		// Update The Grading Details
		submission.setGrade(grade);
		submission.setComment(comment);
		submission.setModifiedDate(new Date());
		
		return super.updateSubmission(submission);
	}
}