package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.model.Submission;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.service.SubmissionLocalService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import java.text.DateFormat;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * MVC Render Command For Showing Editing View of Submission
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_SUBMISSION
	}
	,service = MVCRenderCommand.class
)
public class EditSubmissionMVCRenderCommand implements MVCRenderCommand {
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long submissionId = ParamUtil.getLong(renderRequest, "submissionId", 0);
		try { 
			// Call The Service For Getting Submission For Editing Purpose.
			// Notice The "fetch" command used here as if returns null instead of exception
			Submission submission = _submissionLocalService.fetchSubmission(submissionId);
			long assignmentId;
			if(submission == null) {
				assignmentId = ParamUtil.getLong(renderRequest, "assignmentId");
				System.out.println("assignment : " + assignmentId);
			}
			else {
				assignmentId = submission.getAssignmentId();
			}
			
			// Call For Service To Get The Assignment Information
			Assignment assignment = _assignmentService.getAssignment(assignmentId);
			DateFormat dateFormat = DateFormatFactoryUtil.getSimpleDateFormat("EEEEE, MMMMM dd, yyyy", renderRequest.getLocale());
			
			// Setting Up Request with Submission and Assignment Information
			renderRequest.setAttribute("assignment", assignment);
			renderRequest.setAttribute("submission", submission);
			renderRequest.setAttribute("submissionClass", Submission.class);
			renderRequest.setAttribute("dueDate", dateFormat.format(assignment.getDueDate()));
			
			// Setting Up A Back Icon For Edit View
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();

			String redirect = renderRequest.getParameter("redirect");

			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			return "/submission/edit_submission.jsp";
		}
		catch (PortalException e) {
			throw new PortletException(e);
		}
	}


	@Reference
	private AssignmentService _assignmentService;
	
	@Reference
	private SubmissionLocalService _submissionLocalService;
}
