package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.training.gradebook.service.SubmissionService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * MVC Action Command For Deleting a Submission
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.DELETE_SUBMISSION
	},
	service = MVCActionCommand.class
)
public class DeleteSubmissionMVCActionCommand extends BaseMVCActionCommand{
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		// Get Submission Id From Request
		long submissionId = ParamUtil.getLong(actionRequest, "submissionId");
		try {
			// Call the service to delete the submission.
			_submissionService.deleteSubmission(submissionId);
			
			// Setting Up Delete Message
			SessionMessages.add(actionRequest, "submissionDeleted");
		}
		catch (PortalException e) {
			//e.printStackTrace();
			SessionErrors.add(actionRequest, "serviceErrorDetails", e);
		}
		
		sendRedirect(actionRequest, actionResponse);
	}
	
	@Reference
	protected SubmissionService _submissionService;
}
