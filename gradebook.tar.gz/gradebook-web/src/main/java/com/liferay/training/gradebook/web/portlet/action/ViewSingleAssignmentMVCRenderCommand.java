package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.model.Submission;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.service.SubmissionService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import java.text.DateFormat;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * MVC Command For Showing The Assignment Information and Submission List (Future)
 * 
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class ViewSingleAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay)renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId");
		try {
			// Call For The Service To Get The Assignment Information
			Assignment assignment = _assignmentService.getAssignment(assignmentId);
			
			DateFormat dateFormat = DateFormatFactoryUtil.getSimpleDateFormat("EEEEE, MMMMM dd, YYYY", renderRequest.getLocale());
			
			// Setting Up The Request Attribute With Assignment Values To Be Disolayed In JSP
			renderRequest.setAttribute("assignment", assignment);
			renderRequest.setAttribute("dueDate", dateFormat.format(assignment.getDueDate()));
			renderRequest.setAttribute("createDate", dateFormat.format(assignment.getCreateDate()));
			
			// Add Submission List
			addSubmissionListAttributes(renderRequest, renderResponse, assignmentId);
			
			// Setting Up a Back Icon For Main View Purpose
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
			String redirect = renderRequest.getParameter("redirect");
			
			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			return "/assignment/view_assignment.jsp";
		}
		catch (PortalException pe) {
			throw new PortletException(pe);
		}
	}
	
	private void addSubmissionListAttributes(RenderRequest renderRequest, RenderResponse renderResponse, long assignmentId) throws PortalException {
		// Resolving Of Start and End Of Search
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		int currentPage = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_CUR);
		int delta = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_DELTA_PARAM, SearchContainer.DEFAULT_DELTA);
		
		int start = ((currentPage > 0) ? (currentPage - 1) : 0) * delta;
		int end = start + delta;
		
		// Call The Service To Get The List Of Submission
		// Notice That The Search Only Targets To SubmissionText Field
		List<Submission> submissions = _submissionService.getSubmissionsByAssignment(themeDisplay.getScopeGroupId(), assignmentId, start, end);
		long submissionsCount = _submissionService.getSubmissionsCountByAssignment(themeDisplay.getScopeGroupId(), assignmentId);
		
		// Setting Up Request Attribute with Respect To Submission Data
		renderRequest.setAttribute("submissions", submissions);
		renderRequest.setAttribute("submissionsCount", submissionsCount);
		renderRequest.setAttribute("canAddSubmission", canAddSubmission(renderRequest, submissions));
	}
	
	private boolean canAddSubmission(RenderRequest renderRequest, List<Submission> submissions) throws PortalException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long userId = themeDisplay.getUserId();
		
		boolean hasAlreadySubmitted = false;
		
		if(submissions != null) {
			for(Submission submission : submissions) {
				if(submission.getUserId() == userId) {
					hasAlreadySubmitted = true;
					break;
				}
			}
		}
		
		if (!hasAlreadySubmitted) {
			return true;
		}
		
		return false;
	}
	
	@Reference
	private AssignmentService _assignmentService;
	
	@Reference
	private SubmissionService _submissionService;
}
