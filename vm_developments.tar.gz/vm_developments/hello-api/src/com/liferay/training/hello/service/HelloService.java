package com.liferay.training.hello.service;

public interface HelloService {
	public String say();
	public String say(String message);
}
