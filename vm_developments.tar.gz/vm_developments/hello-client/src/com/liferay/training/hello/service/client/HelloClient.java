package com.liferay.training.hello.service.client;

import com.liferay.training.hello.service.HelloService;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

@Component(
	immediate = true,
	property = {
		"osgi.command.function=say",
		"osgi.command.scope=custom"
	},
	service = Object.class
)
public class HelloClient {
	private HelloService helloService;
	
	public void say() {
		System.out.println(helloService.say());
	}
	
	public void say(String message) {
		System.out.println(helloService.say(message));
	}
	
	@Reference
	(
		policy = ReferencePolicy.DYNAMIC,
		cardinality = ReferenceCardinality.OPTIONAL
	)
	public void setHelloService(HelloService helloService) {
		System.out.println("Setting Up HelloService For Client Calls...");
		this.helloService = helloService;
	}
	public void unsetHelloService(HelloService helloService) {
		System.out.println("Client Implmentation Removed Or Updated...");
		this.helloService = null;
	}
	
	@Activate
	public void testModule() {
		if(helloService != null) {
			System.out.println("HelloService is ready to take client calls");
		}
		else {
			System.out.println("No Service Available By This Name...");
		}
	}
}
