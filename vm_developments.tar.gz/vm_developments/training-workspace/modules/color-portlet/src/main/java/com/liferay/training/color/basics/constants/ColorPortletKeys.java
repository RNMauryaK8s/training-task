package com.liferay.training.color.basics.constants;

/**
 * @author hgrahul
 */
public class ColorPortletKeys {
	public static final String PORTLET_NAME = "com_liferay_training_color_basics_portlet_ColorPortlet";

}