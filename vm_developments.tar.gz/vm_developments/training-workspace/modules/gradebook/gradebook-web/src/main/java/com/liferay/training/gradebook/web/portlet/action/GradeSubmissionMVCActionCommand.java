package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.training.gradebook.exception.SubmissionValidationException;
import com.liferay.training.gradebook.service.SubmissionService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * MVC Action Command For Grading Submission
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.GRADE_SUBMISSION
	},
	service = MVCActionCommand.class
)
public class GradeSubmissionMVCActionCommand extends BaseMVCActionCommand{
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		// Getting Parameter From Request
		System.out.println("action called");
		long submissionId = ParamUtil.getLong(actionRequest, "submissionId");
		int grade = ParamUtil.getInteger(actionRequest, "grade");
		String comment = ParamUtil.getString(actionRequest, "comment");
		System.out.println("action called");
		try {
			// Call For Service To Grade and Comment
			_submissionService.gradeAndCommentSubmission(submissionId, grade, comment);
			
			// Success Message For Grading and Commenting
			SessionMessages.add(actionRequest, "submissionGraded");
			
			sendRedirect(actionRequest, actionResponse);
		}
		catch (SubmissionValidationException e) {
			//e.printStackTrace();
			e.getErrors().forEach(key -> SessionErrors.add(actionRequest, key));
			System.out.println("exception");
		}
	}
	
	@Reference
	protected SubmissionService _submissionService;
}
