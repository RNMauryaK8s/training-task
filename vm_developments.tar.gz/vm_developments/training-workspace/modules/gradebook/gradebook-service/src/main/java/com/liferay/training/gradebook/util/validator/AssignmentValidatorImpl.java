package com.liferay.training.gradebook.util.validator;

import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.MapUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.gradebook.exception.AssignmentValidationException;
import com.liferay.training.gradebook.validator.AssignmentValidator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;

/**
 * 
 * @author hgrahul
 * Implementation For Validator Interface From Gradebook API
 */
@Component(
	immediate = true,
	service = AssignmentValidator.class
)
public class AssignmentValidatorImpl implements AssignmentValidator{
	
	@Override
	public void validate(Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate) throws AssignmentValidationException {
		List<String> errors = new ArrayList<String>();
		
		if(!isAssignmentValid(titleMap, descriptionMap, dueDate, errors)) {
			throw new AssignmentValidationException(errors);
		}
	}
	
	private boolean isAssignmentValid(final Map<Locale, String> titleMap, final Map<Locale, String> descriptionMap, final Date dueDate, final List<String> errors) {
		boolean result = true;
		
		result &= isTitleValid(titleMap, errors);
		result &= isDescriptionValid(descriptionMap, errors);
		result &= isDueDateValid(dueDate, errors);
		
		return result;
	}
	
	private boolean isDueDateValid(final Date dueDate, final List<String> errors) {
		boolean result = true;

		if (Validator.isNull(dueDate)) {
			errors.add("assignmentDateEmpty");
			result = false;
		}

		return result;
	}
	
	private boolean isDescriptionValid(final Map<Locale, String> descriptionMap, final List<String> errors) {
		boolean result = true;
		
		// Verify The Map Has Some Content
		if(MapUtil.isEmpty(descriptionMap)) {
			errors.add("assignmentDescriptionEmpty");
			result = false;
		}
		else {
			// Get Default Locale and Check
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			
			if(Validator.isBlank(descriptionMap.get(defaultLocale))) {
				errors.add("assignmentDescriptionEmpty");
				result = false;
			}
		}
		
		return result;
	}
	
	private boolean isTitleValid(final Map<Locale, String> titleMap, final List<String> errors) {
		boolean result = true;
		
		// Verify The Map Has Some Content
		if(MapUtil.isEmpty(titleMap)) {
			errors.add("assignmentTitleEmpty");
			result = false;
		}
		else {
			// Get Default Locale and Check
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			
			if(Validator.isBlank(titleMap.get(defaultLocale))) {
				errors.add("assignmentTitleEmpty");
				result = false;
			}
		}
		
		return result;
	}
}
