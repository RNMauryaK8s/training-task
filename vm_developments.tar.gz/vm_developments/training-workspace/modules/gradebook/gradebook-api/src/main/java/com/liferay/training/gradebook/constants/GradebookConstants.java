package com.liferay.training.gradebook.constants;

public class GradebookConstants {
	public final static String RESOURCE_NAME = "com.liferay.training.gradebook.model";
}
