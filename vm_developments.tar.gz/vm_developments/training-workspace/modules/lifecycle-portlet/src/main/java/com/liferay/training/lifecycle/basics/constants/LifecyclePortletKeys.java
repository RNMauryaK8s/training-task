package com.liferay.training.lifecycle.basics.constants;

/**
 * @author hgrahul
 */
public class LifecyclePortletKeys {
	public static final String PORTLET_NAME = "com_liferay_training_lifecycle_basics_portlet_LifecyclePortlet";
}