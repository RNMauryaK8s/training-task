package com.liferay.training.message.book.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.training.message.book.Entry;
import com.liferay.training.message.book.constants.MessagebookPortletKeys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ValidatorException;

import org.osgi.service.component.annotations.Component;

/**
 * @author hgrahul
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.training",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Message Book App",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + MessagebookPortletKeys.PORTLET_NAME,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class MessagebookPortlet extends MVCPortlet {
	@ProcessAction(name = "addEntry")
	public void addEntry(ActionRequest actionRequest, ActionResponse actionResponse) throws IOException, PortletException {
		try {
			// As we are storing the information to the portlet preferences object. We first retrieving Portlet Preferences For Persistance Purpose
			PortletPreferences portletPreferences = actionRequest.getPreferences();
			
			// Now Fetching The Value From The Portlet Preferences
			// If Its The Very First Time --> Indeed will recieve null so we have to handle it
			// If its already having some values stored --> Just retrieve
			String messagebookEntries[] = portletPreferences.getValues("messagebook-entries", new String[1]);
			
			// A Temporary Messagebook Arraylist Object For Current Operation
			ArrayList<String> entries = new ArrayList<String>();
			
			if(messagebookEntries[0] != null) {
				entries = new ArrayList<String>(Arrays.asList(
					portletPreferences.getValues("messagebook-entries", new String[1])
				));
			}
			
			// Now Interacting With Form UI
			String name = ParamUtil.getString(actionRequest, "name");
			String message = ParamUtil.getString(actionRequest, "message");
			String email = ParamUtil.getString(actionRequest, "email");
			
			// Form a Message Book Entry
			String entry = name + "|" + email + "|" + message;
			
			// Add To The Temporary Current Object
			entries.add(entry);
			
			// Now The Process To Persist It Down
			String updateArray[] = entries.toArray(new String[entries.size()]);
			
			// Now Using Array For Setting Up The Value Or Updating To Existing One
			portletPreferences.setValues("messagebook-entries", updateArray);
			
			try {
				portletPreferences.store();
			}
			catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		catch(ValidatorException ve) {
			ve.printStackTrace();
		}
	}
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		
		// As we are storing the information to the portlet preferences object. We first retrieving Portlet Preferences For Persistance Purpose
		PortletPreferences portletPreferences = renderRequest.getPreferences();
					
		// Now Fetching The Value From The Portlet Preferences
		// If Its The Very First Time --> Indeed will recieve null so we have to handle it
		// If its already having some values stored --> Just retrieve
		String messagebookEntries[] = portletPreferences.getValues("messagebook-entries", new String[1]);
		
		if(messagebookEntries[0] != null) {
			List<Entry> entries = parseEntries(messagebookEntries);
			renderRequest.setAttribute("entries", entries);
		}
		
		super.render(renderRequest, renderResponse);
	}
	
	private List<Entry> parseEntries(String[] messagebookEntries) {
		List<Entry> entries = new ArrayList<Entry>();
		
		for(String entry : messagebookEntries) {
			String parts[] = entry.split("\\|", 3);
			Entry mbEntry = new Entry(parts[0], parts[1], parts[2]);
			entries.add(mbEntry);
		}
		
		return entries;
	}
}