package com.liferay.training.message.book.constants;

/**
 * @author hgrahul
 */
public class MessagebookPortletKeys {
	public static final String PORTLET_NAME = "com_liferay_training_message_book_portlet_MessagebookPortlet";
}