package com.liferay.training.portlet.basics.constants;

/**
 * @author hgrahul
 */
public class PortletBasicsPortletKeys {
	public static final String PORTLET_NAME= "com_liferay_training_portlet_basics_portlet_PortletBasicsPortlet";
}