package com.liferay.training.hello.service.impl;

import com.liferay.training.hello.service.HelloService;

import org.osgi.service.component.annotations.Component;

@Component(
	immediate = true,
	property = {
	},
	service = HelloService.class
)
public class HelloImplementation implements HelloService{
	int _messageCount = 0;
	
	@Override
	public String say() {
		return "Welcome To Liferay Workshop...";
	}
	
	public String say(String message) {
		String reply = "";
		reply = doInitiateMessage(message);
		return reply;
	}
	
	private String doInitiateMessage(String message) {
		if(message.equalsIgnoreCase("RAHUL")) {
			if(_messageCount == 0) {
				_messageCount += 1;
				return "Hi!! I am Rahul Holalkere From Liferay India :)";
			}
			else {
				return "Hope I Already Introduced Myself.. :) ";
			}
		}
		else {
			_messageCount = 0;
			return "Sorry Unable To Recognize...";
		}
	}	
}
