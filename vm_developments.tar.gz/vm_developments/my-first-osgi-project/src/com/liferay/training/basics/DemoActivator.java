package com.liferay.training.basics;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class DemoActivator implements BundleActivator {

	@Override
	public void start(BundleContext context) throws Exception {
		System.out.println("Module Started Successfully !!!");
	}
	
	@Override
	public void stop(BundleContext context) throws Exception {
		System.out.println("Module Stopped Successfully !!!");
	}

}
